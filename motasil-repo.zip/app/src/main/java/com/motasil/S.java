package com.motasil;
import android.content.Context;
import java.util.Locale;

/** Language helper: Arabic / English, saved in prefs, defaults to system language. */
class S {
    static boolean ar(Context c) {
        String l = c.getSharedPreferences("m", 0).getString("lang", null);
        if (l == null) l = Locale.getDefault().getLanguage();
        return l.equals("ar");
    }
    static void toggle(Context c) {
        c.getSharedPreferences("m", 0).edit().putString("lang", ar(c) ? "en" : "ar").apply();
    }
    static String t(Context c, String en, String ar) { return ar(c) ? ar : en; }
}
