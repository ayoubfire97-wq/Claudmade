package com.motasil;
import android.app.*;
import android.content.*;
import android.net.wifi.WifiClient;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import java.util.*;

public class MonitorService extends Service {
    private WifiManager wm;
    private WifiManager.SoftApCallback cb;
    private SharedPreferences sp;
    private final Set<String> known = new HashSet<>();
    private final Set<String> alerted = new HashSet<>();

    @Override public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("m", 0);
        known.addAll(sp.getStringSet("known", new HashSet<String>()));
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("mon", "Status", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel("alert", "Alerts", NotificationManager.IMPORTANCE_HIGH));
    }

    @Override public int onStartCommand(Intent i, int f, int id) {
        startForeground(1, ongoing());
        if (cb == null) register();
        if (i != null && "TRUST".equals(i.getAction())) trustAll();
        State.running = true;
        State.ping();
        return START_STICKY;
    }

    private void register() {
        wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        cb = new WifiManager.SoftApCallback() {
            @Override public void onStateChanged(int state, int failure) {
                State.ap = state; refresh();
            }
            @Override public void onConnectedClientsChanged(List<WifiClient> clients) {
                List<String> now = new ArrayList<>();
                for (WifiClient c : clients) now.add(c.getMacAddress().toString().toUpperCase());
                State.macs = now;
                alerted.retainAll(now);
                for (String m : now) if (!known.contains(m) && alerted.add(m)) alert(m);
                refresh();
            }
        };
        try {
            wm.registerSoftApCallback(getMainExecutor(), cb);
            State.err = null;
        } catch (Throwable e) {
            State.err = e.getClass().getSimpleName() + ": " + e.getMessage();
        }
        State.ping();
    }

    private void refresh() {
        getSystemService(NotificationManager.class).notify(1, ongoing());
        State.ping();
    }

    private void trustAll() {
        known.addAll(State.macs);
        sp.edit().putStringSet("known", new HashSet<>(known)).apply();
        NotificationManager nm = getSystemService(NotificationManager.class);
        for (String m : State.macs) nm.cancel(m.hashCode());
        alerted.clear();
        State.ping();
    }

    private Notification ongoing() {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        int n = State.macs.size();
        String text = State.ap == 13
                ? S.t(this, n + " device(s) connected", "الأجهزة المتصلة: " + n)
                : S.t(this, "Hotspot is off", "الهوتسبوت مغلق");
        return new Notification.Builder(this, "mon")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle(S.t(this, "Motasil is watching", "متصل يراقب الشبكة"))
                .setContentText(text).setOngoing(true).setContentIntent(open).build();
    }

    private void alert(String mac) {
        Intent t = new Intent(this, MonitorService.class).setAction("TRUST");
        PendingIntent trust = PendingIntent.getForegroundService(this, 2, t,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "alert")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle(S.t(this, "New device connected!", "جهاز جديد اتصل!"))
                .setContentText(mac).setAutoCancel(true).setContentIntent(open)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_add),
                        S.t(this, "Trust all", "ثقة بالكل"), trust).build())
                .build();
        getSystemService(NotificationManager.class).notify(mac.hashCode(), n);
    }

    @Override public void onDestroy() {
        if (cb != null && wm != null) try { wm.unregisterSoftApCallback(cb); } catch (Throwable ignored) {}
        cb = null;
        State.running = false;
        State.macs = new ArrayList<>();
        State.ping();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
