package com.motasil;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import java.util.*;

/** Terminal-style screen: one TextView + 5 plain buttons. No XML, no libraries. */
public class MainActivity extends Activity {
    private TextView out;
    private Button startBtn;

    @Override protected void onCreate(Bundle b) { super.onCreate(b); build(); }

    @Override protected void onResume() {
        super.onResume();
        State.ui = new Runnable() { public void run() { runOnUiThread(new Runnable() { public void run() { refresh(); } }); } };
        refresh();
    }

    @Override protected void onPause() { State.ui = null; super.onPause(); }

    private Button btn(String label, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(label); x.setAllCaps(false); x.setTextColor(0xFF00FF00);
        x.setBackgroundColor(0xFF111111); x.setTypeface(Typeface.MONOSPACE);
        x.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 8; x.setLayoutParams(lp);
        return x;
    }

    private void build() {
        boolean ar = S.ar(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF000000);
        root.setPadding(24, 24, 24, 24);
        root.setLayoutDirection(ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        out = new TextView(this);
        out.setTypeface(Typeface.MONOSPACE); out.setTextSize(15); out.setTextColor(0xFF00FF00);
        out.setTextDirection(ar ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        ScrollView sv = new ScrollView(this);
        sv.addView(out);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        startBtn = btn("", new View.OnClickListener() { public void onClick(View v) { toggle(); } });
        root.addView(startBtn);
        root.addView(btn(S.t(this, "[ Trust all connected ]", "[ ثقة بكل المتصلين ]"),
                new View.OnClickListener() { public void onClick(View v) {
                    if (State.running) startForegroundService(new Intent(MainActivity.this, MonitorService.class).setAction("TRUST"));
                } }));
        root.addView(btn(S.t(this, "[ Hotspot settings (block here) ]", "[ إعدادات الهوتسبوت (الحظر من هنا) ]"),
                new View.OnClickListener() { public void onClick(View v) { openHotspot(); } }));
        root.addView(btn(S.t(this, "[ Keep running in background ]", "[ إبقاء التطبيق يعمل بالخلفية ]"),
                new View.OnClickListener() { public void onClick(View v) {
                    try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception e) {}
                } }));
        root.addView(btn("[ عربي / English ]",
                new View.OnClickListener() { public void onClick(View v) { S.toggle(MainActivity.this); build(); refresh(); } }));
        setContentView(root);
    }

    private void refresh() {
        if (out == null) return;
        boolean ar = S.ar(this);
        Set<String> known = getSharedPreferences("m", 0).getStringSet("known", new HashSet<String>());
        StringBuilder s = new StringBuilder("> MOTASIL | متصل\n\n");
        s.append("> ").append(S.t(this, "Monitor: ", "المراقبة: ")).append(State.running ? "ON" : "OFF").append('\n');
        s.append("> ").append(S.t(this, "Hotspot: ", "الهوتسبوت: "))
                .append(State.ap == 13 ? "ON" : State.ap == 11 ? "OFF" : "?").append('\n');
        s.append("> ").append(S.t(this, "Devices: ", "الأجهزة: ")).append(State.macs.size()).append("\n\n");
        int i = 1;
        for (String m : State.macs) {
            s.append(i++).append(") ").append(m).append("  ")
                    .append(known.contains(m) ? S.t(this, "[trusted]", "[موثوق]") : S.t(this, "[NEW!]", "[جديد!]")).append('\n');
        }
        if (State.err != null) s.append("\n! ").append(State.err).append('\n');
        out.setText(s.toString());
        startBtn.setText(State.running ? S.t(this, "[ STOP ]", "[ إيقاف ]") : S.t(this, "[ START ]", "[ تشغيل ]"));
    }

    private List<String> missing() {
        List<String> l = new ArrayList<>();
        l.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.POST_NOTIFICATIONS);
            l.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        }
        List<String> need = new ArrayList<>();
        for (String p : l) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        return need;
    }

    private void toggle() {
        if (State.running) {
            stopService(new Intent(this, MonitorService.class));
            State.running = false; refresh(); return;
        }
        List<String> need = missing();
        if (!need.isEmpty()) { requestPermissions(need.toArray(new String[0]), 1); return; }
        startForegroundService(new Intent(this, MonitorService.class));
        State.running = true; refresh();
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (missing().isEmpty() && !State.running) toggle(); else refresh();
    }

    private void openHotspot() {
        try { startActivity(new Intent("android.settings.TETHER_SETTINGS")); }
        catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } catch (Exception ignored) {}
        }
    }
}
