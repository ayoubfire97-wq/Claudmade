package com.motasil;
import java.util.ArrayList;
import java.util.List;

/** Tiny shared state between service and screen (no polling, no database). */
class State {
    static volatile List<String> macs = new ArrayList<>();
    static volatile String err = null;
    static volatile boolean running = false;
    static volatile int ap = -1;           // 13 = hotspot on, 11 = off
    static volatile Runnable ui;           // set by the activity while visible
    static void ping() { Runnable r = ui; if (r != null) r.run(); }
}
